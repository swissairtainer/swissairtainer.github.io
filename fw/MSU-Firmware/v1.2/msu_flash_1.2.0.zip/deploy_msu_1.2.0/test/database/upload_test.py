# dd4fd830-ec28-435c-bebc-49975b2795c9

"""
Example script demonstrating how to create a test run using the TofuPilotClient with
a custom test function, including the measurement of test duration, report variables,
and attachments.

This script runs a test, measures its duration, and then creates a test run in TofuPilot,
indicating whether the test passed, and including relevant report variables and attachments.

Ensure your API key is stored in the environment variables as per the documentation:
https://docs.tofupilot.com/user-management#api-key
"""
import json
import os
from datetime import datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
from typing import List
from uuid import UUID

from tofupilot import TofuPilotClient
from tofupilot.models import Step, UnitUnderTest, SubUnit

# Initialize the TofuPilot client
tofu_pilot_api_key = os.environ["TOFUPILOT_API_KEY"]

if tofu_pilot_api_key is None:
    raise ValueError("TOFUPILOT_API_KEY environment variable must be set")

client = TofuPilotClient(api_key=tofu_pilot_api_key)

class MsuTestRun:
    start_time: datetime
    success: bool
    steps: List[Step]
    mcu_id: UUID
    hw_version: str
    fw_version: str
    msu_type: str
    msu_position: int
    measures: List[dict]
    sts31_dis_serial: str | None
    sht40_serial: str | None

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            # Convert Decimal to float with the desired precision
            return float(obj.quantize(Decimal('0.0001'), rounding=ROUND_HALF_UP))
        return super().default(obj)

def create_part_run(serial_number: str, part_number: str, revision: str, batch_number: str | None):
    """
    Create a test run for a part

    Args:
        serial_number: The serial number of the part
        part_number: The part number
        revision: The revision of the part
        batch_number: The batch number of the part
    """

    response = client.create_run(
        procedure_id="MSU_TB_001_Parts",
        unit_under_test=UnitUnderTest(
            serial_number=serial_number,
            part_number=part_number,
            revision=revision,
            batch_number=batch_number
        ),
        run_passed=True,
        started_at=datetime.now(),
        duration=timedelta(seconds=0),
    )

    success = response.get("success")
    assert success


def upload_test_run(test_run: MsuTestRun):
    """
    Uploads the test run to TofuPilot

    Args:
        test_run: The test run to upload
    """

    # Sum of all step durations
    total_duration = timedelta(seconds=0)
    for step in test_run.steps:
        total_duration = timedelta(seconds= step["duration"].total_seconds() + total_duration.total_seconds())

    sub_units = []
    if test_run.sts31_dis_serial:
        sn = f'Sensirion:STS31-DIS:{test_run.sts31_dis_serial}'
        create_part_run(sn, "Sensirion:STS31-DIS", test_run.hw_version, None)
        sub_units.append({"serial_number": sn})

    if test_run.sht40_serial:
        sn = f'Sensirion:SHT40:{test_run.sht40_serial}'
        create_part_run(sn, "Sensirion:SHT40", test_run.hw_version, None)
        sub_units.append({"serial_number": sn})

    # serialize measures to json file
    with open('measures.json', 'w') as json_file:
        json.dump(test_run.measures, json_file, cls=DecimalEncoder)

    # Create a test run in TofuPilot with the results from test_function
    response = client.create_run(
        procedure_id="MSU_TB_001",
        procedure_name="MSU Test Bench",
        unit_under_test= UnitUnderTest(
            serial_number=f'MSU:{test_run.mcu_id}',
            part_number=f"SAT:MSU:{test_run.msu_type}",
            revision=test_run.hw_version,
            batch_number=None
        ),
        run_passed=test_run.success,
        started_at=test_run.start_time,
        duration=total_duration,
        attachments=["measures.json"],
        steps=test_run.steps,
        sub_units=sub_units
    )

    # Ensure the run was successfully created
    success = response.get("success")

    assert success