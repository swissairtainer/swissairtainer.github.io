from datetime import datetime
from uuid import UUID
import fitz  # PyMuPDF for PDF to PNG conversion
from PIL import Image
from blabel import LabelWriter
import os
from labelprinterkit.backends.usb import PyUSBBackend
from labelprinterkit.printers import P700
from labelprinterkit.label import Label, Box, Text, QRCode, Padding
from labelprinterkit.job import Job
from labelprinterkit.page import Page
from labelprinterkit.constants import Media

def convert_pdf_to_png(pdf_path: str, png_path: str, target_height: int = 60, resolution: int = 150):
    """
    Convert PDF to PNG using PyMuPDF with a specified target height while preserving aspect ratio.

    Args:
        pdf_path: Path to source PDF file
        png_path: Path where PNG will be saved
        target_height: Desired height in pixels (default: 60)
        resolution: Initial rendering resolution (default: 150 DPI)
    """
    pdf_document = fitz.open(pdf_path)
    page = pdf_document[0]

    # Get initial pixmap at specified resolution
    matrix = fitz.Matrix(resolution / 72, resolution / 72)
    pix = page.get_pixmap(matrix=matrix)

    # Calculate scaling factor to achieve target height
    scale_factor = target_height / pix.height

    # Create new matrix with adjusted scaling
    adjusted_matrix = fitz.Matrix(
        (resolution / 72) * scale_factor,
        (resolution / 72) * scale_factor
    )

    # Generate final pixmap with correct dimensions
    final_pix = page.get_pixmap(matrix=adjusted_matrix)
    final_pix.save(png_path)
    pdf_document.close()

def print_image(image_file: str):
    job = Job(Media.W9L)
    image = Image.open(image_file)
    image = image.convert("1")
    page = Page.from_image(image)
    job.add_page(page)

    # Initialize printer and print
    backend = PyUSBBackend()
    printer = P700(backend)
    printer.print(job)

def print_mcu_label(
        position: int,
        sensors: str,
        mcu_id: UUID,
        fw_version: str,
        date: datetime = None,
        font_path: str = "label/Roboto-Regular.ttf"):
    """
    Print MCU label with QR code and text information using blabel

    Args:
        position: int - Position (0-10)
        sensors: str - Sensor types (e.g. "TD")
        mcu_id: str - MCU ID (GUID)
        fw_version: str - Firmware version
        date: str - Programming date (optional, defaults to current date)
        generate_img: Save image for debugging/preview (optional, defaults to False)
        font_path: str - Path to Roboto-Regular.ttf font file (optional)
    """
    if not 0 <= position <= 10:
        raise ValueError("Position must be between 0 and 10")

    if date is None:
        date = datetime.now()

    # Generate QR code as base64
    qr_data = f"MSU:{mcu_id}"
    # qr_base64 = generate_qr_base64(qr_data)

    # Prepare the records
    records = [{
        'qr_data': qr_data,
        'sensors': sensors,
        'fw_version': fw_version,
        'date': date.strftime("%Y-%m-%d"),
        'position': f"{position:X}"
    }]

    # Create label writer with font registration
    label_writer = LabelWriter(
        item_template_path="label/label_template.html",
        items_per_page=1,
        font_paths=[font_path]  # Register the font with blabel
    )

    output_file = f"mcu_label_{mcu_id}.pdf"
    label_writer.write_labels(records, target=output_file, base_url="label/")
    png_file = f"mcu_label_{mcu_id}.png"
    convert_pdf_to_png(output_file, png_file)
    print_image(png_file)
    # remove temp files
    os.remove(output_file)
    os.remove(png_file)

def print_mcu_label_old(
        position: int,
        sensors: str,
        mcu_id: UUID,
        fw_version: str,
        date: datetime = None,
        generate_img: bool = False):
    """
    Print MCU label with QR code and text information

    Args:
        position: int - Position (0-10)
        sensors: str - Sensor types (e.g. "TD")
        mcu_id: str - MCU ID (GUID)
        fw_version: str - Firmware version
        date: str - Programming date (optional, defaults to current date)
        generate_img: Save image for debugging/preview (optional, defaults to False)
    """
    if not 0 <= position <= 10:
        raise ValueError("Position must be between 0 and 10")

    if date is None:
        date = datetime.now()

    # Create QR code with MCU ID
    qrcode = QRCode(60, f"MSU:{mcu_id}")

    # Create text elements
    header_text = Text(24, f"MSU:{sensors}", 'Roboto-Regular.ttf', padding=Padding(2, 2, 4, 0))
    version_text = Text(20, f"fw v{fw_version}", 'Roboto-Regular.ttf', padding=Padding(2, 4, 4, 0))
    prog_text = Text(16, date.strftime("%Y-%m-%d"), 'Roboto-Regular.ttf', padding=Padding(2, 4, 0, 0))
    hp_box = Box(60, header_text, version_text, prog_text, vertical=True, left_padding=2)

    pos_text = Text(60, f"[{position:X}]", 'Roboto-Regular.ttf', padding=Padding(3, 1, 1, 0))

    full_box = Box(60, qrcode, hp_box, pos_text)

    # Create and configure label
    label = Label(full_box)

    # Create print job
    job = Job(Media.W9L)
    job.add_page(label)

    # Initialize printer and print
    backend = PyUSBBackend()
    printer = P700(backend)
    printer.print(job)

    # For debugging/preview, save image
    if generate_img:
        label.image.save(f'mcu_{sensors}_{position}_{mcu_id}.png')

