#!/usr/bin/env bash

# Bash setup script for Poetry projects
# Supports macOS and Linux

# Exit on error
set -e

# Colors for output
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Print status message
print_status() {
    echo -e "\n${CYAN}==> $1${NC}"
}

# Print success message
print_success() {
    echo -e "${GREEN}$1${NC}"
}

# Print warning message
print_warning() {
    echo -e "${YELLOW}$1${NC}"
}

# Print error message
print_error() {
    echo -e "${RED}$1${NC}"
}

# Check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Install Python based on OS
install_python() {
    print_status "Installing Python..."

    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS installation using Homebrew
        if ! command_exists brew; then
            print_status "Installing Homebrew..."
            /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

            # Add Homebrew to PATH for Apple Silicon Macs
            if [[ $(uname -m) == 'arm64' ]]; then
                echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
                eval "$(/opt/homebrew/bin/brew shellenv)"
            fi
        fi

        print_status "Installing Python using Homebrew..."
        brew install python

    else
        # Linux installation (assumes apt-based distribution)
        if command_exists apt; then
            print_status "Installing Python using apt..."
            sudo apt update
            sudo apt install -y python3 python3-pip
        else
            print_error "Error: Unsupported Linux distribution. Please install Python manually."
            exit 1
        fi
    fi

    print_success "Python installation completed successfully."
}

# Install Poetry
install_poetry() {
    print_status "Installing Poetry..."

    # Install Poetry using the official installer
    curl -sSL https://install.python-poetry.org | python3 -

    # Add Poetry to PATH
    if [[ "$OSTYPE" == "darwin"* ]]; then
        poetry_path="$HOME/Library/Application Support/pypoetry/venv/bin"
    else
        poetry_path="$HOME/.local/bin"
    fi

    # Add to PATH in current session
    export PATH="$poetry_path:$PATH"

    # Add to PATH permanently
    if [[ -f "$HOME/.zshrc" ]]; then
        echo "export PATH=\"$poetry_path:\$PATH\"" >> "$HOME/.zshrc"
    elif [[ -f "$HOME/.bashrc" ]]; then
        echo "export PATH=\"$poetry_path:\$PATH\"" >> "$HOME/.bashrc"
    fi

    print_success "Poetry installation completed successfully."
}

# Initialize Poetry project
initialize_poetry_project() {
    local project_path="$1"

    print_status "Setting up Poetry project..."

    # Create project directory if it doesn't exist
    if [ ! -d "$project_path" ]; then
        mkdir -p "$project_path"
        echo "Created project directory: $project_path"
    fi

    # Change to project directory
    pushd "$project_path" > /dev/null
    echo "Working in directory: $(pwd)"

    # Initialize new Poetry project if pyproject.toml doesn't exist
    if [ ! -f "pyproject.toml" ]; then
        print_status "Initializing Poetry project..."
        poetry init --no-interaction
    else
        echo "Existing pyproject.toml found, skipping initialization"
    fi

    # Create virtual environment and install dependencies
    print_status "Creating virtual environment and installing dependencies..."
    poetry install

    # Return to original directory
    popd > /dev/null

    print_success "Poetry project setup completed successfully."
}

# Main script execution
main() {
    print_status "Starting Poetry project setup..."

    # Get project path from command line argument or use current directory
    local project_path="${1:-$(pwd)}"
    project_path="$(cd "$(dirname "$project_path")" && pwd)/$(basename "$project_path")"

    # Check for Python
    if ! command_exists python3; then
        install_python
    else
        print_success "Python is already installed: $(python3 --version)"
    fi

    # Check for Poetry
    if ! command_exists poetry; then
        install_poetry
    else
        print_success "Poetry is already installed: $(poetry --version)"
    fi

    # Initialize Poetry project
    initialize_poetry_project "$project_path"

    print_status "Setup completed successfully!"
}

# Run main function
main
