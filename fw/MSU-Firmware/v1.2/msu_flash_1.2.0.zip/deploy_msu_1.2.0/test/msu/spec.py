# 1 tTic1 T
# 2 tTic2 T
# 3 tTic3 T
# 4 tTic4 T
# 5 tTic5 T
# 6 tTic6 T
# 7 tTic7 T
# 8 tTic8 dTic T+D
# 9 tTic9 hTic Pyl1 Shock1  (T+)H+P+S
# a hAmb tAmb (T+)H

from enum import Enum
from typing import NamedTuple


class MsuType(NamedTuple):
    hw_version: str
    temp: bool
    humidity: bool
    shock: bool
    payload: bool
    door: bool

    def to_byte(self) -> int:
        return (self.temp << 0) | (self.humidity << 1) | (self.shock << 2) | (self.door << 3) | (self.payload << 4)

    def __ge__(self, other):
        return (self.hw_version == other.hw_version and (self.temp or not other.temp)
                and (self.humidity or not other.humidity) and (self.shock or not other.shock)
                and (self.payload or not other.payload) and (self.door or not other.door))

class MsuTypes(Enum):
    T = MsuType("1.0.1", temp=True, humidity=False, shock=False, payload=False, door=False)
    TH = MsuType("1.0.1", True, True, False, False, False)
    TD = MsuType("1.0.1", True, False, False, False, True)
    HPS = MsuType("1.0.1", False, True, True, True, False)
    THPSD = MsuType("1.0.1", True, True, True, True, True)

    @staticmethod
    def from_byte(byte: int) -> MsuType:
        return MsuType("1.0.1",
                       temp=byte & 0x01 == 0x01,
                       humidity=byte & 0x02 == 0x02,
                       shock=byte & 0x04 == 0x04,
                       door=byte & 0x08 == 0x08,
                       payload=byte & 0x10 == 0x10)

class MsuPosition(NamedTuple):
    pos: int
    type: MsuTypes
    @property
    def address(self) -> str:
        return f"c{self.pos:07x}"

class RknMsuPositions(Enum):
    P1 = MsuPosition(1, MsuTypes.T)
    P2 = MsuPosition(2, MsuTypes.T)
    P3 = MsuPosition(3, MsuTypes.T)
    P4 = MsuPosition(4, MsuTypes.T)
    P5 = MsuPosition(5, MsuTypes.T)
    P6 = MsuPosition(6, MsuTypes.T)
    P7 = MsuPosition(7, MsuTypes.T)
    P8 = MsuPosition(8, MsuTypes.TD)
    P9 = MsuPosition(9, MsuTypes.HPS)
    P10 = MsuPosition(10, MsuTypes.TH)

    @staticmethod
    def from_position(pos: int) -> MsuPosition | None:
        return next((enum for enum in RknMsuPositions if enum.value.pos == pos), None)