
# Requirements

WeasyPrint:
https://doc.courtbouillon.org/weasyprint/stable/first_steps.html#installation

PyMuPDF:
https://pymupdf.readthedocs.io/en/latest/installation.html

Python:
https://www.python.org/downloads/

Brother P-Touch Cuber Drivers:
https://support.brother.com/g/b/downloadtop.aspx?c=gb&lang=en&prod=p710bteuk

libusb:
https://libusb.info/
* MacOS: `brew install libusb` + ensure lib is in DYLD_LIBRARY_PATH=/opt/homebrew/lib:/usr/local/lib
* Windows: 
  * Download and install the libusb-win32 library from https://github.com/mcuee/libusb-win32/releases/tag/release_1.4.0.0
  * Ensure the library is in the PATH
  * Download zadig from https://github.com/pbatard/libwdi/releases/tag/v1.5.1
  * List all devices in Zadig options, select the printer, and install the libusb-win32 driver.
* Linux: `sudo apt-get install libusb-1.0-0-dev`

# Installation

Use setup.ps1 for Windows or setup.sh for MacOS/Linux to install the required packages.

# Usage

Run the script with the following command:
`python prog_msu.py <position>`
where `<position>` is the position of the MSU. Position must be between 1 and A.