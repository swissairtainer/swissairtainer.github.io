# MSU Test Bench
# Takes the position of the MSU as required parameter
# Actions:
# - Step 1
#   - flashes it with the firmware
#   - retrieve the MSU ID & firmware version using the protocol
#   - repeats in case of error (human intervention required)
# - Step 2
#   - Checks the determined role and assigned role match
#   - Programs the MSU with the assigned role
#   - Programs the MSU assigned position address
#   - (opt)Programs the MSU refresh rate
# - Step 3
#   - Collects the available sensors serial numbers
#   - Collects the role sensor values for 10 seconds
#   - In case of error - exit and human intervention required
# - Step 4
#   - Print the label
#   - Generates label image file
# - Step 5
#   - Send collected data to the server

import sys
from datetime import datetime
import time
from uuid import UUID

from database.upload_test import MsuTestRun, upload_test_run
from flash import flash_msu
from label import print_mcu_label
from msu import Msu, RknMsuPositions, MsuType


# print_mcu_label(10, 'TD', UUID('12345678-1234-5678-1234-567812345678'), '1.0.0')
# exit(0)

# - Step 1
#   - flashes it with the firmware
#   - retrieve the MSU ID & firmware version using the protocol
#   - repeats in case of error (human intervention required)
def step1_flash(really_flash: bool = True):
    begin_dt = datetime.now()
    print('---------------------------------')
    print('Flashing MSU')
    print('---------------------------------')
    while really_flash:
        try:
            flash_msu()
            break
        except Exception as err:
            print(f'Error flashing MSU: {err}')
            print('Check the MSU and try again? (Y/N)')
            answer = input()
            if answer.lower() != 'y':
                raise err
            continue

    time.sleep(5)

    while True:
        try:
            flashed_msu = Msu(Msu.broadcast_address, timeout=.5)
            flashed_msu.open()
            mcu_id = flashed_msu.get_mcu_id()
            print(f'MCU ID: {mcu_id}')
            fw_version = flashed_msu.get_fw_version()
            print(f'Firmware version: {fw_version}')
            flashed_msu.close()
            end_dt = datetime.now()
            print('MSU flashed successfully')
            return end_dt - begin_dt, mcu_id, fw_version
        except Exception as err:
            print(f'Error retrieving fw version: {err}')
            print('Check the MSU and try again? (Y/N)')
            answer = input()
            if answer.lower() != 'y':
                raise err
            continue

# - Step 2
#   - Checks the determined role and assigned role match
#   - Programs the MSU with the assigned role
#   - Programs the MSU assigned position address
#   - (opt)Programs the MSU refresh rate
def step2_program(position: int):
    begin_dt = datetime.now()
    print('---------------------------------')
    print('Configuring MSU')
    print('---------------------------------')
    prg_msu = Msu(Msu.broadcast_address, timeout=.5)
    prg_msu.open()
    mcu_id = prg_msu.get_mcu_id()
    msu_pos = RknMsuPositions.from_position(position)
    pr = msu_pos.value
    print (f'Assigning MCU ID: {mcu_id} to Position: {pr.pos}, Type: {pr.type}')

    ar, dr = prg_msu.get_roles()
    print (f'Position role: {pr.type.value}')
    print (f'Determined role: {dr}')
    if dr >= pr.type.value:
        print ('Roles match')
    else:
        print ('Roles do not match')
        raise ValueError('Roles do not match')

    prg_msu.set_role(pr.type.value.to_byte())
    ar, dr = prg_msu.get_roles()
    print (f'Assigned role: {ar}')
    if ar != pr.type.value:
        raise ValueError('Error setting role')
    else:
        print ('Role set')

    prg_msu.set_address(pr.address)
    time.sleep(5)
    adr = prg_msu.get_address()
    print (f'Position address: {pr.address}, Assigned address: {adr}')
    if adr != pr.address:
        raise ValueError('Error setting address')
    else:
        print ('Address set')
    prg_msu.close()
    end_dt = datetime.now()
    print('MSU configured successfully')
    return end_dt - begin_dt, mcu_id, msu_pos


def step3_collect(position: int):
    begin_dt = datetime.now()
    print('---------------------------------')
    print('Collecting data')
    print('---------------------------------')
    msu_pos = RknMsuPositions.from_position(position).value
    clt_msu = Msu(msu_pos.address, timeout=.5)
    clt_msu.open()
    mcu_id = clt_msu.get_mcu_id()
    values = []
    for i in range(10):
        snapshot = {}
        if msu_pos.type.value.temp:
            snapshot['t'] = clt_msu.get_temp()
        if msu_pos.type.value.humidity:
            snapshot['h'] = clt_msu.get_humidity()
            snapshot['th'] = clt_msu.get_th_temp()
        if msu_pos.type.value.shock:
            try:
                snapshot['s'] = clt_msu.get_shock()
            except Exception as e:
                snapshot['s'] = f'Error: {e}'
        if msu_pos.type.value.payload:
            snapshot['p'] = clt_msu.get_distance()
        if msu_pos.type.value.door:
            snapshot['d'] = clt_msu.get_door_open()
        values.append(snapshot)
        print(f'Snapshot {i+1}: {snapshot}')
        time.sleep(1)

    clt_msu.close()
    print('---------------------------------')
    print('Are the measures correct? (Y/N)')
    answer = input()
    valid = answer.lower() == 'y'
    print('---------------------------------')
    end_dt = datetime.now()
    print('Data collected successfully')
    return end_dt - begin_dt, mcu_id, values, valid

def step4_serials(position: int):
    begin_dt = datetime.now()
    print('---------------------------------')
    print('Retrieving sensors serials')
    print('---------------------------------')
    msu_pos = RknMsuPositions.from_position(position).value
    ser_msu = Msu(msu_pos.address, timeout=.5)
    ser_msu.open()
    mcu_id = ser_msu.get_mcu_id()
    temp_serial = None
    humidity_serial = None
    if msu_pos.type.value.temp:
        temp_serial = ser_msu.get_temp_serial()
        print(f'Temperature sensor serial: {temp_serial:x}')
    if msu_pos.type.value.humidity:
        humidity_serial = ser_msu.get_hum_serial()
        print(f'Humidity sensor serial: {humidity_serial:x}')
    ser_msu.close()
    end_dt = datetime.now()
    print('Sensors serials retrieved successfully')
    return end_dt - begin_dt, mcu_id, temp_serial, humidity_serial


def step5_print(mcu_id: UUID, fw_version: str, position: int):
    begin_dt = datetime.now()
    print('---------------------------------')
    print('Printing label')
    print('---------------------------------')
    msu_pos = RknMsuPositions.from_position(position).value
    print_mcu_label(position, msu_pos.type.name, mcu_id, fw_version)
    print('Label printed successfully')
    end_dt = datetime.now()
    return end_dt - begin_dt

def main(position: int):
    if position < 1 or position > 10:
        raise ValueError('Position out of range expected 1-A')
    start_dt = datetime.now()
    step1_duration, mcu_id1, fw_version = step1_flash()
    step2_duration, mcu_id2, msu_pos = step2_program(position)
    step3_duration, mcu_id3, values, valid = step3_collect(position)
    step4_duration, mcu_id4, temp_serial, humidity_serial = step4_serials(position)
    if not (mcu_id1 == mcu_id2 == mcu_id3 == mcu_id4):
        print('MSU ID match')
        raise ValueError('MSU ID mismatch')

    step5_duration = step5_print(mcu_id1, fw_version, position)
    steps = [{'name': 'Flash', 'started_at': start_dt, 'duration': step1_duration, 'step_passed': True},
             {'name': 'Program', 'started_at': start_dt, 'duration': step2_duration, 'step_passed': True},
             {'name': 'Collect', 'started_at': start_dt, 'duration': step3_duration, 'step_passed': True},
             {'name': 'Serials', 'started_at': start_dt, 'duration': step4_duration, 'step_passed': True},
             {'name': 'Print', 'started_at': start_dt, 'duration': step5_duration, 'step_passed': True}]
    test_run = MsuTestRun()
    test_run.success = valid
    test_run.start_time = start_dt
    test_run.steps = steps
    test_run.mcu_id = mcu_id1
    test_run.hw_version = fw_version
    test_run.msu_type = msu_pos.value.type.name
    test_run.msu_position = position
    test_run.measures = values
    test_run.sts31_dis_serial = temp_serial
    test_run.sht40_serial = humidity_serial
    upload_test_run(test_run)


if __name__ == '__main__':
    #retrieve position and check it is in range 1-10
    print('MSU Test Bench')

    pos = None

    try:
        if len(sys.argv) <= 1:
            print('Usage: prog_msu.py <position>')
            print('Position must be between 1 and A')

            while pos is None:
                pos = input('Enter position: ')
                try:
                    pos = int(pos, 16)
                    if pos < 1 or pos > 10:
                        raise ValueError('Position out of range expected 1-A')
                except ValueError as e:
                    print(e)
                    pos = None
        else:
            pos = int(sys.argv[1], 16)
            if pos < 1 or pos > 10:
                raise ValueError('Position out of range expected 1-A')

        main(pos)
    except ValueError as e:
        print(e)
        sys.exit(1)