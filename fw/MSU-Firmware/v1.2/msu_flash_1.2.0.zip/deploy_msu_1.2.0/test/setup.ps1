# Windows PowerShell setup script for Poetry projects
# Run with administrator privileges for system-wide installation

# Set error action preference to stop on errors
$ErrorActionPreference = "Stop"

function Write-Status {
    param($Message)
    Write-Host "`n==> $Message" -ForegroundColor Cyan
}

function Install-Python {
    Write-Status "Installing Python..."

    # Download Python installer
    $pythonVersion = "3.12.2"
    $pythonUrl = "https://www.python.org/ftp/python/$pythonVersion/python-$pythonVersion-amd64.exe"
    $installerPath = "$env:TEMP\python-installer.exe"

    try {
        Write-Host "Downloading Python $pythonVersion..."
        Invoke-WebRequest -Uri $pythonUrl -OutFile $installerPath

        Write-Host "Running Python installer..."
        # Install Python (silent installation, add to PATH)
        $installArgs = @(
            "/quiet"
            "InstallAllUsers=1"
            "PrependPath=1"
            "Include_test=0"
            "Include_launcher=1"
        )
        Start-Process -FilePath $installerPath -ArgumentList $installArgs -Wait
        Remove-Item $installerPath

        # Refresh environment variables
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" +
                   [System.Environment]::GetEnvironmentVariable("Path", "User")

        Write-Host "Python installation completed successfully." -ForegroundColor Green
    }
    catch {
        Write-Error "Failed to install Python: $_"
        exit 1
    }
}

function Install-Poetry {
    Write-Status "Installing Poetry..."

    try {
        # Install Poetry using official installer
        (Invoke-WebRequest -Uri https://install.python-poetry.org -UseBasicParsing).Content | python -

        # Add Poetry to PATH
        $poetryPath = "$env:APPDATA\Python\Scripts"
        if ($env:Path -notlike "*$poetryPath*") {
            [Environment]::SetEnvironmentVariable(
                "Path",
                [Environment]::GetEnvironmentVariable("Path", "User") + ";$poetryPath",
                "User"
            )
            $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" +
                       [System.Environment]::GetEnvironmentVariable("Path", "User")
        }

        Write-Host "Poetry installation completed successfully." -ForegroundColor Green
    }
    catch {
        Write-Error "Failed to install Poetry: $_"
        exit 1
    }
}

function Initialize-PoetryProject {
    param(
        [string]$ProjectPath
    )

    Write-Status "Setting up Poetry project..."

    try {
        # Create project directory if it doesn't exist
        if (-not (Test-Path $ProjectPath)) {
            New-Item -ItemType Directory -Path $ProjectPath | Out-Null
            Write-Host "Created project directory: $ProjectPath"
        }

        # Change to project directory
        Push-Location $ProjectPath
        Write-Host "Working in directory: $((Get-Location).Path)"

        # Initialize new Poetry project
        Write-Host "Initializing Poetry project..."
        if (-not (Test-Path "pyproject.toml")) {
            poetry init --no-interaction
        } else {
            Write-Host "Existing pyproject.toml found, skipping initialization"
        }

        # Create virtual environment and install dependencies
        Write-Host "Creating virtual environment and installing dependencies..."
        poetry install

        # Return to original directory
        Pop-Location

        Write-Host "Poetry project setup completed successfully." -ForegroundColor Green
    }
    catch {
        if ((Get-Location).Path -eq $ProjectPath) {
            Pop-Location
        }
        Write-Error "Failed to initialize Poetry project: $_"
        exit 1
    }
}

# Main script execution
try {
    Write-Status "Starting Poetry project setup..."

    # Get project path from command line argument or use current directory
    $ProjectPath = if ($args[0]) {
        (Resolve-Path $args[0] -ErrorAction Stop).Path
    } else {
        (Get-Location).Path
    }

    # Check if running as administrator
    $isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
        [Security.Principal.WindowsBuiltInRole] "Administrator"
    )
    if (-not $isAdmin) {
        Write-Warning "This script should be run with administrator privileges for system-wide installation."
        $continue = Read-Host "Continue anyway? (y/N)"
        if ($continue -ne "y") {
            exit 0
        }
    }

    # Check and install Python if needed
    $pythonCmd = Get-Command python -ErrorAction SilentlyContinue
    if (-not $pythonCmd) {
        Install-Python
    }
    else {
        Write-Host "Python is already installed: $($pythonCmd.Version)" -ForegroundColor Green
    }

    # Check and install Poetry if needed
    $poetryCmd = Get-Command poetry -ErrorAction SilentlyContinue
    if (-not $poetryCmd) {
        Install-Poetry
    }
    else {
        Write-Host "Poetry is already installed: $(poetry --version)" -ForegroundColor Green
    }

    # Initialize Poetry project
    Initialize-PoetryProject -ProjectPath $ProjectPath

    Write-Status "Setup completed successfully!"
}
catch {
    Write-Error "An unexpected error occurred: $_"
    exit 1
}
