#!/bin/bash -
echo "MSU program started"

# Absolute path to this script
SCRIPT=$(readlink -f $0)
# Absolute path this script
SCRIPTPATH=`dirname $SCRIPT`

if [[ "$OSTYPE" == "darwin"* ]]; then
  # MacOS
  PATH="/Applications/STMicroelectronics/STM32Cube/STM32CubeProgrammer/STM32CubeProgrammer.app/Contents/MacOs/bin":$PATH
elif [[ "$OSTYPE" == "msys"* || "$OSTYPE" == "cygwin"* ]]; then
  # Windows (MSYS or Cygwin)
  PATH="/C/Program Files/STMicroelectronics/STM32Cube/STM32CubeProgrammer/bin/":$PATH
else
  # Linux assumed
  PATH="/usr/local/STMicroelectronics/STM32Cube/STM32CubeProgrammer/bin/":$PATH
fi

stm32programmercli="STM32_Programmer_CLI"
connect_no_reset="-c port=SWD mode=UR"
connect="-c port=SWD mode=UR --hardRst"

echo "Erasing all Flash memory"
$stm32programmercli "$connect" -e all
ret=$?
if [ $ret != 0 ]; then
  if [ "$1" != "AUTO" ]; then read -p "MSU Program script failed, press a key" -n1 -s; fi
  exit 1
fi
echo "Flash memory erased"

echo "Writing Firmware"
$stm32programmercli "$connect" -d "$SCRIPTPATH"/bin/msu.bin 0x8000000 -v
ret=$?
if [ $ret != 0 ]; then
  if [ "$1" != "AUTO" ]; then read -p "MSU Program script failed, press a key" -n1 -s; fi
  exit 1
fi
echo "Firmware written"

echo "MSU Program Written"
if [ "$1" != "AUTO" ]; then
  read -p "MSU Program script Done, press a key" -n1 -s;
fi

echo "Rebooting target"
$stm32programmercli $connect_no_reset -rst
exit 0
