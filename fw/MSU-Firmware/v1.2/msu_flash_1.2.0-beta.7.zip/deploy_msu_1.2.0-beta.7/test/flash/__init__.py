
def find_bin():
    """Find the MSU binary file.

    Returns:
        str: Path to the MSU binary file

    Raises:
        FileNotFoundError: If the binary file is not found
    """
    import os
    from pathlib import Path

    SCRIPTPATH = Path(__file__).parent.parent.parent.absolute()
    bin_path = SCRIPTPATH / "bin" / "msu.bin"

    if bin_path.exists():
        return str(bin_path)

    bin_path = SCRIPTPATH / "src" / "build" / "release" / "MSU_Firmware.bin"
    if bin_path.exists():
        return str(bin_path)

    bin_path = SCRIPTPATH / "src" / "build" / "debug" / "MSU_Firmware.bin"
    if bin_path.exists():
        return str(bin_path)

    raise FileNotFoundError(f"MSU binary file not found: {bin_path}")

def flash_msu(auto_mode=True):
    """Programs MSU firmware using STM32 programmer CLI tool.

    Args:
        auto_mode (bool): If True, runs without user prompts

    Raises:
        RuntimeError: If programming fails
    """
    import os
    import platform
    import subprocess
    from pathlib import Path

    print("MSU program started")

    SCRIPTPATH = Path(__file__).parent.absolute()

    if platform.system() == "Darwin":
        os.environ["PATH"] = "/Applications/STMicroelectronics/STM32Cube/STM32CubeProgrammer/STM32CubeProgrammer.app/Contents/MacOs/bin:" + \
                      os.environ["PATH"]
    elif platform.system() == "Windows":
        os.environ["PATH"] = r"C:\Program Files\STMicroelectronics\STM32Cube\STM32CubeProgrammer\bin" + os.pathsep + \
                             os.environ["PATH"]
    else:
        os.environ["PATH"] = "/usr/local/STMicroelectronics/STM32Cube/STM32CubeProgrammer/bin:" + os.environ["PATH"]

    stm32programmercli = "STM32_Programmer_CLI"
    connect_no_reset = "-c port=SWD mode=UR"
    connect = "-c port=SWD mode=UR --hardRst"

    def run_command(cmd):
        result = subprocess.run(cmd.split(), capture_output=True, text=True)
        if result.returncode != 0:
            if not auto_mode:
                input("MSU Program script failed, press a key")
            raise RuntimeError(f"Command failed: {cmd}\nOutput: {result.stdout}\nError: {result.stderr}")
        print (f"Success:\r\n{result.stdout}")
        return result

    bin_path = find_bin()
    print(f"Found MSU binary file: {bin_path}")

    print("Erasing all Flash memory")
    run_command(f"{stm32programmercli} {connect} -e all")
    print("Flash memory erased")

    print("Writing Firmware")
    run_command(f'{stm32programmercli} {connect} -d {bin_path} 0x8000000 -v')
    print("Firmware written")

    print("MSU Program Written")
    if not auto_mode:
        input("MSU Program script Done, press a key")

    print("Rebooting target")
    run_command(f"{stm32programmercli} {connect_no_reset} -rst")


__all__ = ['flash_msu']