
# Requirements

WeasyPrint:
https://doc.courtbouillon.org/weasyprint/stable/first_steps.html#installation

Python:
https://www.python.org/downloads/

Brother P-Touch Cuber Drivers:
https://support.brother.com/g/b/downloadtop.aspx?c=gb&lang=en&prod=p710bteuk

libusb:
https://libusb.info/
* MacOS: `brew install libusb` + ensure lib is in DYLD_LIBRARY_PATH=/opt/homebrew/lib:/usr/local/lib
* Windows: https://sourceforge.net/projects/libusb-win32/files/libusb-win32-releases/
* Linux: `sudo apt-get install libusb-1.0-0-dev`