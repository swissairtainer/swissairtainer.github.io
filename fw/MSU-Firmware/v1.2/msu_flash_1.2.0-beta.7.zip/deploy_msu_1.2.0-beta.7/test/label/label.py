from datetime import datetime
import uuid
from uuid import UUID

from labelprinterkit.backends.usb import PyUSBBackend
from labelprinterkit.printers import P700
from labelprinterkit.label import Label, Box, Text, QRCode, Padding
from labelprinterkit.job import Job
from labelprinterkit.constants import Media, MediaType, TapeInfo, Resolution

def print_mcu_label(
        position: int,
        sensors: str,
        mcu_id: UUID,
        fw_version: str,
        date: datetime = None,
        generate_img: bool = False):
    """
    Print MCU label with QR code and text information

    Args:
        position: int - Position (0-10)
        sensors: str - Sensor types (e.g. "TD")
        mcu_id: str - MCU ID (GUID)
        fw_version: str - Firmware version
        date: str - Programming date (optional, defaults to current date)
        generate_img: Save image for debugging/preview (optional, defaults to False)
    """
    if not 0 <= position <= 10:
        raise ValueError("Position must be between 0 and 10")

    if date is None:
        date = datetime.now()

    # Create QR code with MCU ID
    qrcode = QRCode(60, f"MSU:{mcu_id}")

    # Create text elements
    header_text = Text(24, f"{sensors}", 'Roboto-Regular.ttf', padding=Padding(2, 0, 4, 0))
    version_text = Text(20, f"MSU v{fw_version}", 'Roboto-Regular.ttf', padding=Padding(2, 4, 4, 0))
    prog_text = Text(16, date.strftime("%Y-%m-%d"), 'Roboto-Regular.ttf', padding=Padding(2, 4, 0, 0))
    hp_box = Box(60, header_text, version_text, prog_text, vertical=True, left_padding=2)

    pos_text = Text(60, f"[{position:x}]", 'Roboto-Regular.ttf', padding=Padding(3, 1, 1, 0))

    full_box = Box(60, qrcode, hp_box, pos_text)

    # Create and configure label
    label = Label(full_box)

    # Create print job
    job = Job(Media.W9L)
    job.add_page(label)

    # Initialize printer and print
    backend = PyUSBBackend()
    printer = P700(backend)
    printer.print(job)

    # For debugging/preview, save image
    if generate_img:
        label.image.save(f'mcu_{sensors}_{position}_{mcu_id}.png')

