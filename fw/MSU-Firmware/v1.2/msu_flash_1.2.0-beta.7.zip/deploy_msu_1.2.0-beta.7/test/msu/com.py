import struct

from enum import Enum
from typing import Optional, Union
from uuid import UUID

import serial
from serial import Serial
from serial.tools import list_ports

from .spec import MsuTypes, MsuType


class MsuCmdList(Enum):
    # QUERY command = ask for data from PC, GET = command returned by MSU in QUERY answer
    SOF = b'\xAA'
    CMD_UNKNOWN = b'\x01'
    ACK = b'\x02'
    NACK = b'\x03'
    GENERIC_ERROR = b'\x04'
    SENSOR_NOT_PRESENT = b'\x05'

    QUERY_ID = b'\x07'
    GET_ID = b'\x08'
    SET_ID = b'\x09'

    QUERY_ROLE = b'\x33'
    GET_ROLE = b'\x34'
    SET_ROLE = b'\x35'

    QUERY_STS31_SERIAL = b'\x50'
    GET_STS31_SERIAL = b'\x51'
    QUERY_SHT40_SERIAL = b'\x52'
    GET_SHT40_SERIAL = b'\x53'

    QUERY_MCU_ID = b'\x10'
    GET_MCU_ID = b'\x11'
    QUERY_FW_VERSION = b'\x12'
    GET_FW_VERSION = b'\x13'
    SET_TH_THRESHOLD = b'\x20'
    SET_SAMPLE_RATE = b'\x30'
    QUERY_T = b'\x40'
    GET_T = b'\x41'
    QUERY_TH = b'\x42'
    GET_TH = b'\x43'
    QUERY_H = b'\x44'
    GET_H = b'\x45'
    QUERY_SHOCK = b'\x46'
    GET_SHOCK = b'\x47'
    QUERY_DISTANCE = b'\x48'
    GET_DISTANCE = b'\x49'
    QUERY_TAMP = b'\x4A'
    GET_TAMP = b'\x4B'


class NoPacketError(Exception):
    pass


class NackReceivedException(Exception):
    pass


class BadStartOfFrame(Exception):
    pass


class WrongLength(Exception):
    pass


class BadXorCheck(Exception):
    pass


class NoAnswerFromMsu(Exception):
    pass


class ErrorFlagInAnswer(Exception):
    pass


class SensorNotPresent(Exception):
    pass


class DistanceSensorNotPresent(Exception):
    pass


class WrongCmdInAnswer(Exception):
    pass


class ShockSensorNotPresent(Exception):
    pass


class MultipleMastersOnline(Exception):
    pass


class DistanceSensorProblem(Exception):
    pass


class Answer:
    length: int
    dest_addr: hex
    source_addr: hex
    cmd: MsuCmdList
    data: Union[bool, float, UUID, str, bytes]


def get_rs485_port():
    for port in list_ports.comports():
        if 'USB Serial' in port.description:
            return port.device
    return None


class Msu:
    address: hex
    timeout: float
    testbench_address: hex = '10000001'
#    golden_sample_addresses: list[hex] = ['f0000001', 'f0000002', 'f0000003']
    default_address: hex = '0a0b0c0d'
    broadcast_address: hex = 'fffffffe'
    _cmd: bytes
    _packet: bytes
    _serial_port: Serial
    _answer: Answer

    def __init__(self, address: hex = None, timeout: float = 0.2):
        self._answer = Answer()
        self.address = f'{int(address, base=16):08x}'
        self.timeout = timeout

    def open(self, com_port: str = None):
        if com_port is None:
            com_port = get_rs485_port()
        self._serial_port = serial.Serial(port=com_port, baudrate=9600, bytesize=8,
                                          timeout=self.timeout, stopbits=serial.STOPBITS_ONE)
        print(f'MSU port {com_port} opened')

    def __enter__(self, com_port: str):
        self.open(com_port)
        return self

    def close(self):
        self._serial_port.close()
        # print('COM port closed')

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def get_address(self):
        self._send(MsuCmdList.QUERY_ID, destination=self.address)
        self._listen()
        if self._answer.cmd is not MsuCmdList.GET_ID:
            raise ConnectionError('Communication error: ' + self._answer.cmd.name + ' ' + self._answer.data)
        print(f'Connection test passed with MSU {self._answer.data}')
        return self._answer.data

    def set_address(self, new_address: hex):
        new_address = f'{int(new_address, base=16):08x}'
        self._send(MsuCmdList.SET_ID, data=bytes.fromhex(new_address), destination=self.address)
        self.address = new_address
        og = self.timeout
        self.timeout = 0.5
        self._listen()
        self.timeout = og
        if self._answer.cmd is not MsuCmdList.ACK:
            raise ConnectionError('Address could not be set, communication error: '
                                  + self._answer.cmd.name + ' ' + self._answer.data)


    def get_mcu_id(self) -> UUID:
        self._send(MsuCmdList.QUERY_MCU_ID)
        self._listen()
        if self._answer.cmd is not MsuCmdList.GET_MCU_ID:
            raise WrongCmdInAnswer
        return self._answer.data

    def get_fw_version(self) -> str:
        self._send(MsuCmdList.QUERY_FW_VERSION)
        self._listen()
        if self._answer.cmd is not MsuCmdList.GET_FW_VERSION:
            raise WrongCmdInAnswer
        return self._answer.data

    def get_temp_serial(self) -> int:
        self._send(MsuCmdList.QUERY_STS31_SERIAL)
        self._listen()
        if self._answer.cmd is not MsuCmdList.GET_STS31_SERIAL:
            raise WrongCmdInAnswer
        return self._answer.data

    def get_hum_serial(self) -> int:
        self._send(MsuCmdList.QUERY_SHT40_SERIAL)
        self._listen()
        if self._answer.cmd is not MsuCmdList.GET_SHT40_SERIAL:
            raise WrongCmdInAnswer
        return self._answer.data

    def get_roles(self) -> tuple[MsuType, MsuType]:
        self._send(MsuCmdList.QUERY_ROLE)
        self._listen()
        if self._answer.cmd is not MsuCmdList.GET_ROLE:
            raise WrongCmdInAnswer

        # date is two bytes
        returned_bytes = bytes(self._answer.data)
        ar, dr = returned_bytes[0], returned_bytes[1]
        return MsuTypes.from_byte(ar), MsuTypes.from_byte(dr)

    def set_role(self, role: int):
        self._send(MsuCmdList.SET_ROLE, data=bytes([role]))
        self._listen()
        if self._answer.cmd is not MsuCmdList.ACK:
            raise ConnectionError('Role could not be set, communication error: '
                                  + self._answer.cmd.name + ' ' + self._answer.data)

    def get_temp(self) -> float:
        self._send(MsuCmdList.QUERY_T)
        self._listen()
        if self._answer.cmd is not MsuCmdList.GET_T:
            raise WrongCmdInAnswer
        return self._answer.data

    def get_humidity(self) -> float:
        self._send(MsuCmdList.QUERY_H)
        self._listen()
        if self._answer.cmd is not MsuCmdList.GET_H:
            raise WrongCmdInAnswer
        return self._answer.data

    def get_th_temp(self) -> float:
        self._send(MsuCmdList.QUERY_TH)
        self._listen()
        if self._answer.cmd is not MsuCmdList.GET_TH:
            raise WrongCmdInAnswer
        return self._answer.data

    def get_shock(self) -> float:
        self._send(MsuCmdList.QUERY_SHOCK)
        self._listen()
        if self._answer.cmd is not MsuCmdList.GET_SHOCK:
            raise WrongCmdInAnswer
        return self._answer.data

    def get_distance(self) -> float:
        self._send(MsuCmdList.QUERY_DISTANCE)
        try:
            self._listen()
        except NoAnswerFromMsu as e:
            raise DistanceSensorProblem from e
        if self._answer.cmd is not MsuCmdList.GET_DISTANCE:
            raise WrongCmdInAnswer
        return self._answer.data

    def get_door_open(self) -> bool:
        self._send(MsuCmdList.QUERY_TAMP)
        self._listen()
        if self._answer.cmd is not MsuCmdList.GET_TAMP:
            raise WrongCmdInAnswer
        return self._answer.data

    def detect_type(self):  # Door must be open for this to work properly
        try:
            self.get_temp()
        except SensorNotPresent:
            try:
                self.get_distance()
            except SensorNotPresent as e:
                raise DistanceSensorNotPresent from e
            try:
                self.get_shock()
            except SensorNotPresent as e:
                raise ShockSensorNotPresent from e

            return MsuTypes.HPS

        try:
            self.get_humidity()
            try:
                self.get_distance()
            except SensorNotPresent:
                return MsuTypes.TH
        except SensorNotPresent:
            if self.get_door_open():
                return MsuTypes.TD
            return MsuTypes.T

        # if the function did not return, the MSU has all the sensors
        return MsuTypes.THPSD

    def _send(self, command: MsuCmdList, data: Optional[bytes] = b'', destination: Optional[hex] = None) -> None:
        if not destination:
            destination = self.address
        payload = bytes.fromhex(destination) + bytes.fromhex(self.testbench_address) + command.value + data
        self._packet = b'\xAA' + bytes([len(payload)]) + payload
        self._packet = self._packet + self._xor()
        self._serial_port.write(self._packet)
        self._answer.data = None

    def _listen(self) -> Answer:
        # read until start of frame
        temp = self._serial_port.read(11)
        if not temp:
            raise NoAnswerFromMsu
        if temp[0:1] != b'\xAA':
            raise BadStartOfFrame

        expected_total_len = int.from_bytes(temp[1:2], "big") + 3 # 11 - 2

        temp += self._serial_port.read(expected_total_len - 11)
        if calculate_xor(temp[:-1]) != temp[-1:]:
            raise BadXorCheck

        self._answer.length = len(temp) - 3
        self._answer.dest_addr = temp[2:6].hex()
        self._answer.source_addr = temp[6:10].hex()
        self._answer.cmd = MsuCmdList(temp[10:11])

        if self._answer.cmd in [MsuCmdList.GENERIC_ERROR, MsuCmdList.CMD_UNKNOWN, MsuCmdList.NACK]:
            raise ErrorFlagInAnswer(self._answer.cmd.name)
        if self._answer.cmd is MsuCmdList.SENSOR_NOT_PRESENT:
            raise SensorNotPresent
        if self._answer.cmd in [MsuCmdList.GET_T, MsuCmdList.GET_H, MsuCmdList.GET_TH, MsuCmdList.GET_DISTANCE, MsuCmdList.GET_SHOCK]:
            self._answer.data = struct.unpack('f', temp[11:-1])[0]  # data content is a 4-bytes floating point number
        if self._answer.cmd in [MsuCmdList.GET_TAMP]:
            self._answer.data = bool.from_bytes(temp[11:12], 'big')  # 2 tamper bytes possible, only 1 used
        if self._answer.cmd is MsuCmdList.GET_ID:
            self._answer.data = temp[11:-1].hex()
        if self._answer.cmd is MsuCmdList.GET_ROLE:
            self._answer.data = temp[11:-1]
        if self._answer.cmd is MsuCmdList.GET_MCU_ID:
            self._answer.data = UUID(temp[11:-1].split(b'\x00')[0].decode('utf-8'))
        if self._answer.cmd is MsuCmdList.GET_FW_VERSION:
            self._answer.data = temp[11:-1].split(b'\x00')[0].decode('utf-8')
        if self._answer.cmd in [MsuCmdList.GET_STS31_SERIAL, MsuCmdList.GET_SHT40_SERIAL]:
            self._answer.data = int.from_bytes(temp[11:-1], 'little')

        if self._answer.dest_addr != self.testbench_address:
            raise MultipleMastersOnline

        return self._answer

    def _xor(self) -> bytes:
        return calculate_xor(self._packet)


def calculate_xor(packet) -> bytes:
    try:
        xor = packet[0]
        temp_packet = packet[1:]
        for b in temp_packet:
            xor ^= b
    except NameError as e:
        raise NoPacketError from e
    return bytes([xor])

# Example code:
# msu = Msu(Msu.default_address, listen_delay=0.2)  # f0000001 f0000002 f0000003
# msu.open('COM10')
# msu.test_connection()
# msu.detect_type()
# print(msu.type)
# # # # # # # print(msu.humidity)
# # # # # # # # print(msu.shock_g)
# # # # # # # print(msu.calibrated_temp)
# # # # # # # print(msu.hum_sens_temp)
# # # # # print(msu.door_open)
# # print("Answer:")
# # print(msu._answer.__dict__)
# msu.close()
