# dd4fd830-ec28-435c-bebc-49975b2795c9

"""
Example script demonstrating how to create a test run using the TofuPilotClient with
a custom test function, including the measurement of test duration, report variables,
and attachments.

This script runs a test, measures its duration, and then creates a test run in TofuPilot,
indicating whether the test passed, and including relevant report variables and attachments.

Ensure your API key is stored in the environment variables as per the documentation:
https://docs.tofupilot.com/user-management#api-key
"""
import os
from datetime import datetime, timedelta
from typing import List
from uuid import UUID

from tofupilot import TofuPilotClient
from tofupilot.models import Step, UnitUnderTest, SubUnit

# Initialize the TofuPilot client
tofu_pilot_api_key = os.environ["TOFUPILOT_API_KEY"]

if tofu_pilot_api_key is None:
    raise ValueError("TOFUPILOT_API_KEY environment variable must be set")

client = TofuPilotClient(api_key=tofu_pilot_api_key)

class MsuTestRun:
    start_time: datetime
    steps: List[Step]
    mcu_id: UUID
    hw_version: str
    fw_version: str
    msu_type: str
    msu_position: int
    measures: List[dict]
    sts31_dis_serial: str | None
    sht40_serial: str | None


def upload_test_run(test_run: MsuTestRun):
    """
    Uploads the test run to TofuPilot

    Args:
        test_run: The test run to upload
    """

    # Sum of all step durations
    total_duration = sum(step["duration"] for step in test_run.steps)

    sub_units = []
    if test_run.sts31_dis_serial:
        # su = SubUnit(serial_number=test_run.sts31_dis_serial)
        sub_units.append({"serial_number": f'STS31-DIS:{test_run.sts31_dis_serial}'})

    if test_run.sht40_serial:
        sub_units.append({"serial_number": f'SHT40:{test_run.sts31_dis_serial}'})

    # convert each measure in test_run.measures to a string
    attachments = []
    for measure in test_run.measures:
        attachments.append(str(measure))

    # Create a test run in TofuPilot with the results from test_function
    response = client.create_run(
        procedure_id="MSU_TB_001",
        procedure_name="MSU Test Bench",
        unit_under_test= UnitUnderTest(
            serial_number=f'{test_run.mcu_id}',
            part_number=f"MSU-{test_run.msu_type}",
            revision=test_run.hw_version,
            batch_number=None
        ),
        run_passed=True,
        started_at=test_run.start_time,
        duration=timedelta(seconds=total_duration),
        attachments=attachments,
        steps=test_run.steps,
        sub_units=sub_units
    )

    # Ensure the run was successfully created
    success = response.get("success")

    assert success