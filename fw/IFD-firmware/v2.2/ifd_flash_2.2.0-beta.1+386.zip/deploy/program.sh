#!/bin/bash -
./regression.sh AUTO && ./SBSFU_UPDATE.sh AUTO
