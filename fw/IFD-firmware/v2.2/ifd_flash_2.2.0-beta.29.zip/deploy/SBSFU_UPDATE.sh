#!/bin/bash - 
echo "SBSFU_UPDATE started"
# Absolute path to this script
SCRIPT=$(readlink -f $0)
# Absolute path this script
SCRIPTPATH=`dirname $SCRIPT`

if [[ "$OSTYPE" == "darwin"* ]]; then
  # MacOS
  PATH="/Applications/STMicroelectronics/STM32Cube/STM32CubeProgrammer/STM32CubeProgrammer.app/Contents/MacOs/bin":$PATH
elif [[ "$OSTYPE" == "msys"* || "$OSTYPE" == "cygwin"* ]]; then
  # Windows (MSYS or Cygwin)
  PATH="/C/Program Files/STMicroelectronics/STM32Cube/STM32CubeProgrammer/bin/":$PATH
else
  echo "Unsupported OS: $OSTYPE"
  exit 1
fi

stm32programmercli="STM32_Programmer_CLI"
connect_no_reset="-c port=SWD mode=UR freq=4000"
connect="-c port=SWD freq=4000 mode=UR --hardRst"
slot0=0xc00e000
slot1=0x0
slot2=0xc043000
slot3=0x0
boot=0xc001000
loader=0xc07b000
cfg_loader=1

echo "Write SBSFU_Appli"
$stm32programmercli $connect -d $SCRIPTPATH/bin/sbsfu_sign.bin $slot0 -v
ret=$?
if [ $ret != 0 ]; then
  if [ "$1" != "AUTO" ]; then read -p "SBSFU_UPDATE script failed, press a key" -n1 -s; fi
  exit 1
fi
echo "SBSFU_Appli Written"

# write loader if config loader is active
if [ $cfg_loader == 1 ]; then
echo "Write SBSFU_Loader"
$stm32programmercli $connect -d $SCRIPTPATH/bin/loader.bin $loader -v
ret=$?
if [ $ret != 0 ]; then
  if [ "$1" != "AUTO" ]; then read -p "SBSFU_UPDATE script failed, press a key" -n1 -s; fi
  exit 1
fi
echo "SBSFU_Loader Written"
fi

echo "Write SBSFU_Boot"
$stm32programmercli $connect -d $SCRIPTPATH/bin/boot.bin $boot -v
ret=$?
if [ $ret != 0 ]; then
  if [ "$1" != "AUTO" ]; then read -p "SBSFU_UPDATE script failed, press a key" -n1 -s; fi
  exit 1
fi
echo "SBSFU_Boot Written"
if [ "$1" != "AUTO" ]; then
  read -p "SBSFU_UPDATE script Done, press a key" -n1 -s;
fi

echo "Rebooting target"
$stm32programmercli $connect_no_reset -rst
exit 0